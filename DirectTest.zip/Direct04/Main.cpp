#include "Main.h"

int main() {
	drawableCircleCount = 100;
	InitializeCriticalSection(&criticalClick);
	DisplayWindow();
	InitializeDirect();
	GenerateCircles();
	CreateActionButtons();
	InitializeThread();
	StartMessageLoop();
	DeleteCriticalSection(&criticalClick);
	return 0;
}

void DisplayWindow() {
	HINSTANCE h = GetModuleHandle(0);
	WNDCLASSEX wclass = { 0 };
	wclass.cbSize = sizeof(wclass);
	wclass.style = CS_VREDRAW | CS_HREDRAW;
	wclass.hInstance = h;
	wclass.hCursor = LoadCursor(0, IDC_ARROW);
	wclass.lpfnWndProc = EventHandler;
	wclass.lpszClassName = APP_NAME;
	RegisterClassEx(&wclass);
	int u = CW_USEDEFAULT;
	Window = CreateWindowEx(0, APP_NAME, APP_NAME, WS_THICKFRAME, u, u, u, u, 0, 0, h, 0);
	
	ShowWindow(Window, 1);
}
LRESULT EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LRESULT res = 0;
	static RECT borderThickness;
	switch (msg) {
		case WM_CLOSE:
		case WM_DESTROY: {
			PostQuitMessage(0);
			isRunning = FALSE;
		} break;
		case WM_CREATE: {
			GetClientRect(hwnd, &windowRect);
			contentHeight = windowRect.bottom - titleHeight;
			HINSTANCE ins = (HINSTANCE)GetWindowLong(hwnd, GWLP_HINSTANCE);
			titleBar = CreateWindowExW(0, L"static", 0, WS_CHILD | WS_VISIBLE, 0, 0, windowRect.right, titleHeight, hwnd, 0, ins, 0);
			content = CreateWindowExW(0, L"static", 0, WS_CHILD | WS_VISIBLE, 0, titleHeight, windowRect.right, contentHeight, hwnd, 0, ins, 0);
		}
		case WM_ACTIVATE: {
			SetRectEmpty(&borderThickness);
			AdjustWindowRectEx(&borderThickness, GetWindowLongPtr(hwnd, GWL_STYLE) & ~WS_CAPTION, FALSE, NULL);
			borderThickness.left *= -1;
			borderThickness.top *= -1;

			GetClientRect(hwnd, &windowRect);
			SetWindowRgn(hwnd, CreateRoundRectRgn(0, 0, windowRect.right, windowRect.bottom, cornerRadius, cornerRadius), true);
		} break;
		case WM_NCCALCSIZE: break;
		case WM_NCHITTEST: {
			POINT point;
			GetCursorPos(&point);
			ScreenToClient(hwnd, &point);
			RECT rc;
			GetClientRect(hwnd, &rc);
			enum { left = 1, top = 2, right = 4, bottom = 8 };
			int hit = 0;
			if (point.x < borderThickness.left) hit |= left;
			if (point.x > rc.right - borderThickness.right) hit |= right;
			if (point.y < borderThickness.top) hit |= top;
			if (point.y > rc.bottom - borderThickness.bottom) hit |= bottom;

			if (hit & top && hit & left) return HTTOPLEFT;
			if (hit & top && hit & right) return HTTOPRIGHT;
			if (hit & bottom && hit & left) return HTBOTTOMLEFT;
			if (hit & bottom && hit & right) return HTBOTTOMRIGHT;
			if (hit & left) return HTLEFT;
			if (hit & top) return HTTOP;
			if (hit & right) return HTRIGHT;
			if (hit & bottom) return HTBOTTOM;

			return HTCLIENT;
		}
		case WM_SIZE: {		
			WINDOWPLACEMENT placement;
			GetWindowPlacement(hwnd, &placement);
			if (placement.showCmd == SW_MAXIMIZE) {
				windowWidth = LOWORD(lParam) - 14;
				windowHeight = HIWORD(lParam) - 14;
				contentHeight = windowHeight - titleHeight;
				titlebarY = 7;
				SetWindowRgn(hwnd, CreateRoundRectRgn(titlebarY, titlebarY, windowWidth + titlebarY, windowHeight + titlebarY, cornerRadius, cornerRadius), true);
				MoveWindow(titleBar, titlebarY, titlebarY, windowWidth, titleHeight, TRUE);
				MoveWindow(content, titlebarY, titlebarY + titleHeight, windowWidth, contentHeight, TRUE);
			}
			else {
				windowWidth = LOWORD(lParam);
				windowHeight = HIWORD(lParam);
				contentHeight = windowHeight - titleHeight;
				titlebarY = 0;
				SetWindowRgn(hwnd, CreateRoundRectRgn(0, 0, windowWidth, windowHeight, cornerRadius, cornerRadius), true);
				MoveWindow(titleBar, 0, 0, windowWidth, titleHeight, TRUE);
				MoveWindow(content, 0, titleHeight, windowWidth, contentHeight, TRUE);
			}
			

			if (xTarget) {
				xTarget->Resize(D2D1::SizeU(windowWidth, contentHeight));
				for (int i = 0; i < circleCount; i++) {
					circles[i].item.point.x = circles[i].item.point.x / previousWindowWidth * windowWidth;
					circles[i].item.point.y = circles[i].item.point.y / previousWindowHeight * contentHeight;
				}
				float width = 100.f;
				float height = 50.f;
				float top = titleHeight;
				float left = windowWidth - 110;
				for (int i = 0; i < rectangleCount; i++) {
					rectangles[i].item.left = left;
					rectangles[i].item.top = top;
					rectangles[i].item.right = left + width;
					rectangles[i].item.bottom = top + height;
					top += (height + 10);
				}
			}
			if (titleTarget) {
				titleTarget->Resize(D2D1::SizeU(windowWidth, titleHeight));
			}
			
			
			
			previousWindowWidth = windowWidth;
			previousWindowHeight = contentHeight;
		} break;
		case WM_MOUSEMOVE: {
			if (!isMouseOver) {
				isMouseOver = TRUE;
				SetEvent(mouseOverEvent);
				TRACKMOUSEEVENT tme = { sizeof(tme) };
				tme.dwFlags = TME_LEAVE;
				tme.hwndTrack = hwnd;
				TrackMouseEvent(&tme);
			}
		} break;
		case WM_MOUSELEAVE: {
			isMouseOver = false;
			ResetEvent(mouseOverEvent);
		} break;
		case WM_LBUTTONDOWN: {
			POINT point;
			GetCursorPos(&point);
			ScreenToClient(hwnd, &point);
			if(point.x > 0 && point.x < (windowWidth - 90) && point.y > 0 && point.y < titleHeight)
				PostMessage(hwnd, WM_SYSCOMMAND, SC_SIZE + 9, 0);

		} break;
		case WM_LBUTTONUP: {
			POINT point;
			GetCursorPos(&point);

			EnterCriticalSection(&criticalClick);
			clickQueue.push(point);
			LeaveCriticalSection(&criticalClick);
			SetEvent(leftClickEvent);
		} break;
		default:
			res = DefWindowProc(hwnd, msg, wParam, lParam);
			break;
	}
	return res;
}
void StartMessageLoop() {
	isRunning = TRUE;
	NTTime ntTime;
	HMODULE ntHandle = GetModuleHandleA("ntdll.dll");
	if ((ntTime = (NTTime)GetProcAddress(ntHandle, "NtQueryTimerResolution")) == NULL) {
		MessageBox(0, L"Failed loading ntdll.dll", L"Error", MB_OK | MB_ICONERROR);
		//return 0;
	}
	ntTime(&perfMon.MinTimerRes, &perfMon.MaxTimerRes, &perfMon.CurrentTimerRes);

	timeBeginPeriod(1);
	perfMon.displayData = TRUE;
	perfMon.FPSCalcInterval = 120;
	FPS_CONTROLLER fps = { 0 };
	fps.process = GetCurrentProcess();
	fps.targetMicroSecPerFrame = 16667;
	GetSystemInfo(&perfMon.systemInfo);
	QueryPerformanceFrequency((LARGE_INTEGER*)&perfMon.frequency);
	GetSystemTimeAsFileTime((FILETIME*)&perfMon.previousSystemTime);
	MSG msg;
	while (isRunning) {
		QueryPerformanceCounter((LARGE_INTEGER*)&fps.frameStart);
		while (PeekMessage(&msg, 0, 0, 0, PM_REMOVE) > 0) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		ProcessInput();
		Render();
		ControlFPS(&fps, &perfMon);
	}
}
void ControlFPS(FPS_CONTROLLER* fps, PERFMON* perf) {
	QueryPerformanceCounter((LARGE_INTEGER*)&fps->frameEnd);
	fps->elapsedMicroSeconds = fps->frameEnd - fps->frameStart;
	fps->elapsedMicroSeconds *= 1000000;
	fps->elapsedMicroSeconds /= perf->frequency;
	perf->framesRendered++;
	fps->realTotalMicroSeconds += fps->elapsedMicroSeconds;

	while (fps->elapsedMicroSeconds < fps->targetMicroSecPerFrame) {
		fps->elapsedMicroSeconds = fps->frameEnd - fps->frameStart;
		fps->elapsedMicroSeconds *= 1000000;
		fps->elapsedMicroSeconds /= perf->frequency;
		QueryPerformanceCounter((LARGE_INTEGER*)&fps->frameEnd);
		if (fps->elapsedMicroSeconds < (fps->targetMicroSecPerFrame * 0.75f)) {
			Sleep(1); // Play around sleep time for different monitor resolution and check CPU usage
		}
	}
	fps->cooketTotalMicroSeconds += fps->elapsedMicroSeconds;

	if ((perf->framesRendered % perf->FPSCalcInterval) == 0) {
		GetSystemTimeAsFileTime((FILETIME*)&perf->currentSystemTime);
		GetProcessTimes(fps->process,
			&fps->processCreationTime,
			&fps->processExitTime,
			(FILETIME*)&fps->currentKernelCPUTime,
			(FILETIME*)&fps->currentUserCPUTime);

		perf->cpuPercent = (fps->currentKernelCPUTime - fps->previousKernelCPUTime) + (fps->currentUserCPUTime - fps->previousUserCPUTime);
		perf->cpuPercent /= (perf->currentSystemTime - perf->previousSystemTime); // check
		perf->cpuPercent /= perf->systemInfo.dwNumberOfProcessors;
		perf->cpuPercent *= 100;

		GetProcessHandleCount(fps->process, &perf->handleCount);
		GetProcessMemoryInfo(fps->process, (PROCESS_MEMORY_COUNTERS*)&perf->memInfo, sizeof(perf->memInfo));
		perf->realFPS = 1.0f / ((fps->realTotalMicroSeconds / perf->FPSCalcInterval) * 0.000001f);
		perf->cookedFPS = 1.0f / ((fps->cooketTotalMicroSeconds / perf->FPSCalcInterval) * 0.000001f);
		fps->realTotalMicroSeconds = 0;
		fps->cooketTotalMicroSeconds = 0;

		fps->previousKernelCPUTime = fps->currentKernelCPUTime;
		fps->previousUserCPUTime = fps->currentUserCPUTime;
		perf->previousSystemTime = perf->currentSystemTime;
	}
}
void ProcessInput() {
	int16_t isEscape = GetAsyncKeyState(VK_ESCAPE);
	int16_t isF = GetAsyncKeyState('F');
	static int16_t wasF = 0;
	if (isEscape) {
		SendMessage(Window, WM_CLOSE, 0, 0);
		isRunning = FALSE;
	}
	/*if (isF && !wasF) {
		isFullScreen = !isFullScreen;
		if (isFullScreen) {
			GetWindowRect(window, &windowRect);
			MakeWindowFullScreen();
		}
		else {
			SetWindowLongPtr(window, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
			SetWindowPos(window, HWND_NOTOPMOST, windowRect.left, windowRect.top, windowRect.right, windowRect.bottom, SWP_FRAMECHANGED);
		}
	}
	wasF = isF;*/
}
void Render() {
	DrawTitlebar();
	xTarget->BeginDraw();
	xTarget->Clear(D2D1::ColorF(D2D1::ColorF::White, 0.2f));
	brush->SetColor(D2D1::ColorF(D2D1::ColorF::CornflowerBlue));
	xTarget->FillRoundedRectangle(D2D1::RoundedRect(D2D1::RectF(0, 0, windowWidth, windowHeight - titleHeight), cornerRadius, cornerRadius), brush);
	DrawCircles();
	DrawRectangles();
	DrawDebugText();
	xTarget->EndDraw();
}
void InitializeDirect() {
	D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &xFactory);
	//D2D1::RenderTargetProperties(
	//	D2D1_RENDER_TARGET_TYPE_DEFAULT,
	//	D2D1::PixelFormat(DXGI_FORMAT_UNKNOWN, D2D1_ALPHA_MODE_PREMULTIPLIED))

	xFactory->CreateHwndRenderTarget(
		D2D1::RenderTargetProperties(),
		D2D1::HwndRenderTargetProperties(titleBar, D2D1::SizeU(windowWidth, titleHeight), D2D1_PRESENT_OPTIONS_IMMEDIATELY),
		&titleTarget);
	titleTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &titleBrush);

	xFactory->CreateHwndRenderTarget(
		D2D1::RenderTargetProperties(),
		D2D1::HwndRenderTargetProperties(content, D2D1::SizeU(windowWidth, contentHeight), D2D1_PRESENT_OPTIONS_IMMEDIATELY),
		&xTarget);
	xTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &brush);

	DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&writer));
	writer->CreateTextFormat(
		L"Arial",                // Font family name.
		NULL,                    // Font collection (NULL sets it to use the system font collection).
		DWRITE_FONT_WEIGHT_BOLD,
		DWRITE_FONT_STYLE_NORMAL,
		DWRITE_FONT_STRETCH_NORMAL,
		30,
		L"en-us",
		&contentTextFormat
	);
	writer->CreateTextFormat(
		L"Arial",                // Font family name.
		NULL,                    // Font collection (NULL sets it to use the system font collection).
		DWRITE_FONT_WEIGHT_BOLD,
		DWRITE_FONT_STYLE_NORMAL,
		DWRITE_FONT_STRETCH_NORMAL,
		18,
		L"en-us",
		&titleTextFormat
	);
	titleTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
	titleTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
}
void GenerateCircles() {
	CIRCLE circle;
	for (int i = 0; i < 1500; i++) {
		int radius = rand() % 100;
		circle.item = D2D1::Ellipse(
			D2D1::Point2F(rand() % windowWidth, rand() % windowHeight),
			radius,
			radius
		);
		circle.grow = radius > 50 ? FALSE : TRUE;
		circle.color = D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f);
		circles[i] = circle;
	}
	RECTANGLE rect;
	float width = 100.f;
	float height = 50.f;
	float top = 10;
	float left = windowWidth - 110;

	for (int i = 0; i < rectangleCount; i++) {
		float x = left;
		float y = top;
		float right = x + width;
		float bottom = y + height;

		rect.isMouseOver = FALSE;
		rect.normal = D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f);
		rect.item = D2D1::RectF(x, y, right, bottom);

		switch (i) {
			case 0: rect.onClick = make100; rect.name = L"100"; break;
			case 1: rect.onClick = make250; rect.name = L"250"; break;
			case 2: rect.onClick = make500; rect.name = L"500"; break;
			case 3: rect.onClick = make1000; rect.name = L"1000"; break;
			case 4: rect.onClick = make1500; rect.name = L"1500"; break;
		}
		rectangles[i] = rect;
		top += (height + 10);
	}
}
void CreateActionButtons() {
	titleTarget->QueryInterface(&context);
	
	IStream* stream;
	SHCreateStreamOnFileW(L"svgs/minimize.svg", STGM_READ, &stream);
	context->CreateSvgDocument(stream, { (float)1, (float)1 }, &minimize.svg);

	SHCreateStreamOnFileW(L"svgs/maximize.svg", STGM_READ, &stream);
	context->CreateSvgDocument(stream, { (float)1, (float)1 }, &maximize.svg);

	SHCreateStreamOnFileW(L"svgs/close.svg", STGM_READ, &stream);
	context->CreateSvgDocument(stream, { (float)1, (float)1 }, &close.svg);

	minimize.svg->GetRoot(&minimize.element);
	minimize.svg->CreatePaint(D2D1_SVG_PAINT_TYPE_COLOR, D2D1::ColorF(D2D1::ColorF::Black), 0, &minimize.fill);
	minimize.element->SetAttributeValue(L"fill", minimize.fill);

	maximize.svg->GetRoot(&maximize.element);
	maximize.svg->CreatePaint(D2D1_SVG_PAINT_TYPE_COLOR, D2D1::ColorF(D2D1::ColorF::Black), 0, &maximize.fill);
	maximize.element->SetAttributeValue(L"fill", maximize.fill);

	close.svg->GetRoot(&close.element);
	close.svg->CreatePaint(D2D1_SVG_PAINT_TYPE_COLOR, D2D1::ColorF(D2D1::ColorF::Black), 0, &close.fill);
	close.element->SetAttributeValue(L"fill", close.fill);

	stream->Release();
}
void InitializeThread() {
	mouseOverThread = CreateThread(0, 0, PollMouseOver, 0, 0, 0);
	leftClickThread = CreateThread(0, 0, PollLeftClick, 0, 0, 0);
	mouseOverEvent = CreateEvent(0, TRUE, FALSE, L"MouseOverEvent");
	leftClickEvent = CreateEvent(0, TRUE, FALSE, L"LeftClickEvent");
}
DWORD PollMouseOver(void* param) {
	while (isRunning) {
		WaitForSingleObject(mouseOverEvent, INFINITE);
		POINT point, contentPoint;
		GetCursorPos(&point);
		contentPoint = point;
		ScreenToClient(content, &contentPoint);
		for (int i = 0; i < rectangleCount; i++) {
			if (contentPoint.x > rectangles[i].item.left &&
				contentPoint.x < rectangles[i].item.right &&
				contentPoint.y > rectangles[i].item.top &&
				contentPoint.y < rectangles[i].item.bottom) {
				rectangles[i].isMouseOver = TRUE;
			}
			else {
				rectangles[i].isMouseOver = FALSE;
			}
		}

		ScreenToClient(Window, &point);
		int x = windowWidth - 90;
		for (int i = 0; i < 3; i++) {
			switch (i) {
				case 0: {
					if (point.x > x &&
						point.x < (x + 24) &&
						point.y > (titlebarY + 2) && point.y < (titlebarY + 24)) {
						minimize.fill->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
					}
					else {
						minimize.fill->SetColor(D2D1::ColorF(D2D1::ColorF::Black));
					}
				} break;
				case 1: {
					if (point.x > x &&
						point.x < (x + 24) &&
						point.y >(titlebarY + 2) && point.y < (titlebarY + 24)) {
						maximize.fill->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
					}
					else {
						maximize.fill->SetColor(D2D1::ColorF(D2D1::ColorF::Black));
					}
				} break;
				case 2: {
					if (point.x > x &&
						point.x < (x + 24) &&
						point.y >(titlebarY + 2) && point.y < (titlebarY + 24)) {
						close.fill->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
					}
					else {
						close.fill->SetColor(D2D1::ColorF(D2D1::ColorF::Black));
					}
				} break;
			}
			x += 30;
		}
		
		Sleep(5);
	}
	CloseHandle(mouseOverThread);
	CloseHandle(mouseOverEvent);
	return 0;
}
DWORD PollLeftClick(void* param) {
	while (isRunning) {
		WaitForSingleObject(leftClickEvent, INFINITE);
		if (clickQueue.empty()) {
			Sleep(5);
			continue;
		}

		EnterCriticalSection(&criticalClick);
		POINT point = clickQueue.front();
		clickQueue.pop();
		LeaveCriticalSection(&criticalClick);
		POINT contentPoint = point;
		ScreenToClient(content, &contentPoint);
		for (int i = 0; i < rectangleCount; i++) {
			if (contentPoint.x > rectangles[i].item.left &&
				contentPoint.x < rectangles[i].item.right &&
				contentPoint.y > rectangles[i].item.top &&
				contentPoint.y < rectangles[i].item.bottom) {
				rectangles[i].onClick();
			}
		}
		ScreenToClient(Window, &point);
		int x = windowWidth - 90;
		for (int i = 0; i < 3; i++) {
			switch (i) {
				case 0: {
					if (point.x > x &&
						point.x < (x + 24) &&
						point.y >(titlebarY + 2) && point.y < (titlebarY + 24)) {
						PostMessage(Window, WM_SYSCOMMAND, SC_MINIMIZE, 0);
					}
				} break;
				case 1: {
					if (point.x > x &&
						point.x < (x + 24) &&
						point.y >(titlebarY + 2) && point.y < (titlebarY + 24)) {

						WINDOWPLACEMENT placement;
						GetWindowPlacement(Window, &placement);
						if (placement.showCmd == SW_MAXIMIZE) {
							PostMessage(Window, WM_SYSCOMMAND, SC_RESTORE, 0);
						}
						else PostMessage(Window, WM_SYSCOMMAND, SC_MAXIMIZE, 0);
					}
				} break;
				case 2: {
					if (point.x > x &&
						point.x < (x + 24) &&
						point.y >(titlebarY + 2) && point.y < (titlebarY + 24)) {
						isRunning = FALSE;
						PostQuitMessage(0);
					}
				} break;
			}
			x += 30;
		}
		ResetEvent(leftClickEvent);
		Sleep(5);
	}
	CloseHandle(leftClickThread);
	CloseHandle(leftClickEvent);
	return 0;
}
void DrawTitlebar() {
	titleTarget->BeginDraw();
	titleTarget->Clear(D2D1::ColorF(D2D1::ColorF::Gray));

	context->SetTransform(D2D1::Matrix3x2F::Translation(windowWidth - 90, 2));
	context->DrawSvgDocument(minimize.svg);
	context->SetTransform(D2D1::Matrix3x2F::Translation(windowWidth - 60, 2));
	context->DrawSvgDocument(maximize.svg);
	context->SetTransform(D2D1::Matrix3x2F::Translation(windowWidth -30, 2));
	context->DrawSvgDocument(close.svg);
	context->SetTransform(D2D1::Matrix3x2F::Translation(0, 0));

	titleBrush->SetColor(D2D1::ColorF(D2D1::ColorF::DarkGreen));
	wchar_t buff[24] = { 0 };
	_swprintf(buff, L"Direct Test");
	titleTarget->DrawText(buff, wcslen(buff), titleTextFormat, D2D1::RectF(5, 0, windowWidth, titleHeight), titleBrush);

	titleBrush->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
	titleTarget->DrawLine(D2D1::Point2F(0, titleHeight), D2D1::Point2F(windowWidth, titleHeight), titleBrush, 3);
	titleTarget->EndDraw();
}
void DrawCircles() {
	for (int i = 0; i < drawableCircleCount; i++) {
		if (circles[i].item.radiusX > 75) {
			circles[i].grow = FALSE;
		}
		else if (circles[i].item.radiusX < 10) {
			circles[i].grow = TRUE;
		}
		if (circles[i].grow) {
			circles[i].item.radiusX++;
			circles[i].item.radiusY++;
		}
		else {
			circles[i].item.radiusX--;
			circles[i].item.radiusY--;
		}
		brush->SetColor(circles[i].color);
		xTarget->DrawEllipse(&circles[i].item, brush, 3);
	}
}
void DrawRectangles() {
	contentTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
	contentTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
	for (int i = 0; i < rectangleCount; i++) {
		if (rectangles[i].isMouseOver) {
			brush->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
		}
		else {
			brush->SetColor(rectangles[i].normal);
		}
		xTarget->FillRoundedRectangle(D2D1::RoundedRect(rectangles[i].item, 10, 10), brush);
		brush->SetColor(D2D1::ColorF(D2D1::ColorF::White));
		xTarget->DrawText(
			rectangles[i].name,
			wcslen(rectangles[i].name),
			contentTextFormat,
			D2D1::RectF(rectangles[i].item.left, rectangles[i].item.top, rectangles[i].item.right, rectangles[i].item.bottom),
			brush);
	}
}
void DrawDebugText() {
	contentTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
	contentTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
	brush->SetColor(D2D1::ColorF(D2D1::ColorF::White));
	int y = 10;
	int bottom = 30;

	wchar_t buff[128] = { 0 };
	_swprintf(buff, L"Real FPS: %.02f", perfMon.realFPS);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, bottom), brush);

	y += bottom;
	_swprintf(buff, L"Cooked FPS: %.02f", perfMon.cookedFPS);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"Min Timer: %.02f", perfMon.MinTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"Max Timer: %.02f", perfMon.MaxTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"Current Timer: %.02f", perfMon.CurrentTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"Handles: %lu", perfMon.handleCount);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"Memory Usage: %lu MB", perfMon.memInfo.PrivateUsage / (1024 * 1024));
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"CPU Usage: %.02f %%", perfMon.cpuPercent);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"Surface: %dx%d", windowWidth, windowHeight);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);

	y += bottom;
	_swprintf(buff, L"No. of Circle: %d", drawableCircleCount);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), brush);
}