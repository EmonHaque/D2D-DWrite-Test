#pragma once
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define NO_STRICT
#pragma comment(linker, "/subsystem:Windows")
#pragma comment(linker, "/entry:mainCRTStartup")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "shlwapi.lib")

#include <Windows.h>
#include <d2d1.h>
#include <d2d1_3.h>
#include <dwrite.h>
#include <shlwapi.h>
#include <stdint.h>
#include <stdio.h>
#include <queue>
#include "Structs.h"

#define APP_NAME L"Direct Test"
typedef LONG(NTAPI* NTTime) (PULONG min, PULONG max, PULONG current);

RECT windowRect;
HWND Window, titleBar, content;
BOOL isRunning, isMouseOver;
PERFMON perfMon;
HANDLE mouseOverThread, leftClickThread, leftClickEvent, mouseOverEvent;;
CRITICAL_SECTION criticalClick;
std::queue<POINT> clickQueue;
ID2D1Factory* xFactory;
ID2D1HwndRenderTarget* xTarget, *titleTarget;
ID2D1SolidColorBrush* brush, *titleBrush;
IDWriteFactory* writer;
IDWriteTextFormat* contentTextFormat, *titleTextFormat;
ID2D1DeviceContext5* context;
const int cornerRadius = 20;
const int titleHeight = 32;
const int rectangleCount = 5;
const int circleCount = 1500;
CIRCLE circles[circleCount];
RECTANGLE rectangles[rectangleCount];
ACTION_BUTTON minimize, maximize, close;
int drawableCircleCount;
int windowWidth, windowHeight, contentHeight, titlebarY;
int previousWindowWidth, previousWindowHeight;

void DisplayWindow();
LRESULT CALLBACK EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void StartMessageLoop();
void ProcessInput();
void Render();
void ControlFPS(FPS_CONTROLLER* fps, PERFMON* perf);
void InitializeDirect();
void GenerateCircles();
void CreateActionButtons();
void DrawTitlebar();
void DrawCircles();
void DrawDebugText();
void DrawRectangles();
void InitializeThread();
DWORD PollMouseOver(void* param);
DWORD PollLeftClick(void* param);

void make100() { drawableCircleCount = 100; }
void make250() { drawableCircleCount = 250; }
void make500() { drawableCircleCount = 500; }
void make1000() { drawableCircleCount = 1000; }
void make1500() { drawableCircleCount = 1500; }