#pragma once
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")

#include <d2d1.h>
#include <d2d1_3.h>
#include <d2d1svg.h>
#include <dwrite.h>
#include <Shlwapi.h>
#include <Windows.h>

typedef void (*onButtonClicked)(void);

class Button {
	ID2D1HwndRenderTarget* target;
	//ID2D1DCRenderTarget* target;
	ID2D1SolidColorBrush* brush, *textBrush;
	IDWriteFactory* writer;
	IDWriteTextFormat* textFormat;

	ID2D1DeviceContext5* context;
	ID2D1SvgDocument* svg;
	ID2D1SvgElement* element;
	ID2D1SvgPaint* fill;

	HWND hwnd;
	int id, width, height;
	bool isOver, isDown, isDestroyed;
    wchar_t* text;
	onButtonClicked action;
    static LRESULT CALLBACK EventHandler(HWND, UINT, WPARAM, LPARAM);
	void Draw();
	static DWORD WINAPI Animate(void*);
public:
	Button(HWND parent, int id, int width, int height, wchar_t* text);
	~Button();
	void SetPosition(int x, int y);	
	void SetOnClick(onButtonClicked callback){ action = callback; }
};