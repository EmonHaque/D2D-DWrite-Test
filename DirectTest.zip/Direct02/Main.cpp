#include <Windows.h>
#include "InitialView.h"

ID2D1Factory* factory;
int windowWidth, windowHeight;

LRESULT CALLBACK EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LRESULT res = 0;
	switch (msg) {
	case WM_QUIT:
	case WM_DESTROY: PostQuitMessage(0); break;
	case WM_CREATE: {
		RECT rect;
		GetClientRect(hwnd, &rect);
		windowWidth = rect.right;
		windowHeight = rect.bottom;
		CreateInitialView(hwnd);
	} break;
	case WM_SIZE: {
		windowWidth = LOWORD(lParam);
		windowHeight = HIWORD(lParam);
		ResizeInitialView();
	} break;
	default:
		res = DefWindowProcW(hwnd, msg, wParam, lParam);
		break;
	}
	return res;
}
int WINAPI WinMain(HINSTANCE h, HINSTANCE, LPSTR, int) {
	HRESULT red = CoInitializeEx(0, COINIT_MULTITHREADED);
	D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &factory);
	const wchar_t* name = L"App";
	WNDCLASS wclass = {};
	wclass.lpszClassName = name;
	wclass.hCursor = LoadCursor(0, IDC_ARROW);
	wclass.lpfnWndProc = EventHandler;
	wclass.style = CS_HREDRAW | CS_VREDRAW;
	wclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);

	RegisterClass(&wclass);
	RegisterInitialView(wclass);

	int x = CW_USEDEFAULT;
	CreateWindow(name, name, WS_VISIBLE|WS_OVERLAPPEDWINDOW, x, x, x, x, 0, 0, h, 0);
	
	MSG msg;
	while (GetMessage(&msg, 0, 0, 0) > 0) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

