#pragma once
#include "Button.h";

#define CONTAINER 10001
extern int windowWidth;
extern int windowHeight;
const wchar_t* name = L"InitView";
HWND initialViewContainer;

void onButtonClick() { 
	OutputDebugStringA("Button Click Handler called\n"); 
}
LRESULT CALLBACK InitialViewHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LRESULT res = 0;
	switch (msg) {
	case WM_CREATE: {
		int y = 0;
		int id = 50000;	
		for (int i = 0; i < 15; i++) {
			int x = 0;
			for (int j = 0; j < 35; j++) {
				auto c = new wchar_t[1];
				c[0] = rand() % 26 + 65;
				auto b = new Button(hwnd, ++id, 32, 32, c);
				b->SetOnClick(&onButtonClick);
				b->SetPosition(x, y);
				x += 35;
			}
			y += 35;
		}
	} break;
	default:
		res = DefWindowProcW(hwnd, msg, wParam, lParam);
		break;
	}
	return res;
}
void RegisterInitialView(WNDCLASS cClass) {
	cClass.lpszClassName = name;
	cClass.lpfnWndProc = InitialViewHandler;
	RegisterClass(&cClass);

}
void CreateInitialView(HWND parent) {
	initialViewContainer = CreateWindowW(name, 0, WS_CHILDWINDOW|WS_VISIBLE, 0, 0, windowWidth, windowHeight,
		parent, (HMENU)(CONTAINER), (HINSTANCE)GetWindowLong(parent, GWLP_HINSTANCE), 0);
}
void ResizeInitialView() {
	MoveWindow(initialViewContainer, 0, 0, windowWidth, windowHeight, FALSE);
}