#include "Button.h"

extern ID2D1Factory* factory;

LRESULT CALLBACK Button::EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LRESULT res = 0;
	Button* bThis = reinterpret_cast<Button*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
	switch (msg) {
	case WM_PAINT: {
		OutputDebugStringA("painting\n");
		PAINTSTRUCT paint;
		HDC dc = BeginPaint(hwnd, &paint);
		bThis->Draw();
		EndPaint(hwnd, &paint);
		ReleaseDC(hwnd, dc);
	} break;
	case WM_MOUSEFIRST: {
		if (!bThis->isOver) {
			bThis->isOver = true;
			TRACKMOUSEEVENT tme = { sizeof(tme) };
			tme.dwFlags = TME_LEAVE;
			tme.hwndTrack = hwnd;
			TrackMouseEvent(&tme);

			OutputDebugStringA("first\n");
			bThis->brush->SetColor(D2D1::ColorF(D2D1::ColorF::Coral));
			bThis->textBrush->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
			bThis->fill->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
			InvalidateRect(hwnd, 0, TRUE);
		}
	} break;
	case WM_LBUTTONDOWN: {
		OutputDebugStringA("down\n");
		bThis->brush->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
		bThis->textBrush->SetColor(D2D1::ColorF(D2D1::ColorF::Green));
		bThis->fill->SetColor(D2D1::ColorF(D2D1::ColorF::Coral));
		InvalidateRect(hwnd, 0, TRUE);
		bThis->isDown = true;

		TRACKMOUSEEVENT tme = { sizeof(tme) };
		tme.dwFlags = TME_LEAVE;
		tme.hwndTrack = hwnd;
		TrackMouseEvent(&tme);
	}
	case WM_LBUTTONUP: {
		if (bThis->isDown) {
			res = DefWindowProcW(hwnd, msg, wParam, lParam);
			OutputDebugStringA("up reset\n");
		}
		else {
			OutputDebugStringA("up\n");
			/*float cx = (float)bThis->width / 2.f;
			float cy = (float)bThis->height / 2.f;*/
			bThis->brush->SetColor(D2D1::ColorF(D2D1::ColorF::Coral));
			bThis->textBrush->SetColor(D2D1::ColorF(D2D1::ColorF::Red));

			/*HANDLE thread = CreateThread(0, 0, Button::Animate, bThis, 0, 0);
			OutputDebugStringA("thread started\n");
			WaitForSingleObject(thread, INFINITE);
			CloseHandle(thread);*/

			/*for (int i = 0; i < 360; i++) {
				bThis->target->SetTransform(D2D1::Matrix3x2F::Rotation((float)i, D2D1::Point2F(cx, cy)));
				InvalidateRect(hwnd, 0, TRUE);
				UpdateWindow(hwnd);
			}*/
			bThis->action();
			delete bThis;
		}
	}
	case WM_MOUSELEAVE: {
		if (bThis->isDown) {
			res = DefWindowProcW(hwnd, msg, wParam, lParam);
			bThis->isDown = false;
			OutputDebugStringA("leave reset\n");
		}
		else if (!bThis->isDestroyed) {
			OutputDebugStringA("leave\n");
			bThis->brush->SetColor(D2D1::ColorF(D2D1::ColorF::CornflowerBlue));
			bThis->textBrush->SetColor(D2D1::ColorF(D2D1::ColorF::White));
			bThis->fill->SetColor(D2D1::ColorF(D2D1::ColorF::Black));
			InvalidateRect(hwnd, 0, TRUE);
			bThis->isOver = false;
		}
	} break;
	default:
		res = DefWindowProcW(hwnd, msg, wParam, lParam);
		break;
	}
	//wchar_t buff[50];
	//wsprintf(buff, L"ID: %d MSG: %d\n", bThis->id, msg);
	//OutputDebugStringW(buff);
	//return CallWindowProc(bThis->proc, hwnd, msg, wParam, lParam);
	return res;
}
Button::Button(HWND parent, int id, int width, int height, wchar_t* text) :
	action(0), isDown(false), isOver(false), isDestroyed(false),
	width(width), height(height), id(id), text(text) {
	WNDCLASS wclass = {};
	wclass.lpszClassName = L"xxx";
	wclass.lpfnWndProc = Button::EventHandler;
	wclass.hCursor = LoadCursor(0, IDC_ARROW);
	RegisterClass(&wclass);
	hwnd = CreateWindowW(wclass.lpszClassName, 0, WS_CHILDWINDOW | WS_VISIBLE, 0, 0, width, height,
		parent, (HMENU)(id), (HINSTANCE)GetWindowLong(parent, GWLP_HINSTANCE), 0);

	SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)this);

	factory->CreateHwndRenderTarget(
		D2D1::RenderTargetProperties(),
		D2D1::HwndRenderTargetProperties(hwnd, D2D1::SizeU(width, height), D2D1_PRESENT_OPTIONS_IMMEDIATELY),
		&target);

	//D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties(
	//	D2D1_RENDER_TARGET_TYPE_DEFAULT,
	//	D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE),
	//	0,
	//	0,
	//	D2D1_RENDER_TARGET_USAGE_NONE,
	//	D2D1_FEATURE_LEVEL_DEFAULT
	//);
	//factory->CreateDCRenderTarget(&props, &target);
	//RECT rc;
	//GetClientRect(hwnd, &rc);
	//target->BindDC(GetDC(hwnd), &rc);

	target->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &brush);
	target->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::White), &textBrush);

	DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&writer));
	writer->CreateTextFormat(
		L"Arial",                // Font family name.
		NULL,                    // Font collection (NULL sets it to use the system font collection).
		DWRITE_FONT_WEIGHT_REGULAR,
		DWRITE_FONT_STYLE_NORMAL,
		DWRITE_FONT_STRETCH_NORMAL,
		28.0f,
		L"en-us",
		&textFormat
	);
	textFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
	textFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

	IStream* stream;
	SHCreateStreamOnFileW(L"svgs/print.svg", STGM_READ, &stream);
	target->QueryInterface(&context);
	context->CreateSvgDocument(stream, { (float)1, (float)1 }, &svg);
	stream->Release();

	svg->GetRoot(&element);
	svg->CreatePaint(D2D1_SVG_PAINT_TYPE_COLOR, D2D1::ColorF(D2D1::ColorF::Black), 0, &fill);
	element->SetAttributeValue(L"fill", fill);
}
void Button::SetPosition(int x, int y) {
	MoveWindow(hwnd, x, y, width, height, TRUE);
	Draw();
}
DWORD WINAPI Button::Animate(void* param) {
	OutputDebugStringA("in thread\n");
	Button* b = (Button*)param;
	float cx = (float)b->width / 2.f;
	float cy = (float)b->height / 2.f;
	for (int i = 0; i < 360; i++) {
		OutputDebugStringA("in thread loop\n");
		b->target->SetTransform(D2D1::Matrix3x2F::Rotation((float)i, D2D1::Point2F(cx, cy)));
		InvalidateRect(b->hwnd, 0, TRUE);
		UpdateWindow(b->hwnd);
		wchar_t buff[50];
		wsprintf(buff, L"Degree: %d\n", i);
		OutputDebugStringW(buff);
	}
	return 0;
}
void Button::Draw() {
	target->BeginDraw();
	target->Clear(D2D1::ColorF(D2D1::ColorF::White));
	target->FillRectangle(D2D1::RectF(0, 0, width, height), brush);
	target->DrawText(text, 1, textFormat, D2D1::RectF(0, 0, width, height), textBrush);
	target->EndDraw();

	/*context->BeginDraw();
	context->Clear(D2D1::ColorF(D2D1::ColorF::White));
	context->DrawSvgDocument(svg);
	context->EndDraw();*/
}
Button::~Button() {
	DestroyWindow(hwnd);
	target->Release();
	brush->Release();
	textBrush->Release();
	writer->Release();
	textFormat->Release();
	delete text, target, brush, textBrush, writer, textFormat;

	/*svg->Release();
	context->Release();
	element->Release();
	fill->Release();
	delete svg, context, element, fill;*/

	OutputDebugStringA("Deleted\n");
	isDestroyed = true;
}