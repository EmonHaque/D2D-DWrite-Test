#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define NO_STRICT
#pragma comment(linker, "/subsystem:Windows")
#pragma comment(linker, "/entry:mainCRTStartup")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "winmm.lib")

#include <Windows.h>
#include <d2d1.h>
#include <dwrite.h>
#include <stdint.h>
#include <stdio.h>
#include <queue>
#include "Structs.h"

#define APP_NAME L"Direct Test"
typedef LONG(NTAPI* NTTime) (PULONG min, PULONG max, PULONG current);

BOOL isFullScreen, isMouseOver;
RECT windowRect;
HANDLE mouseOverThread, leftClickThread, leftClickEvent, mouseOverEvent;
CRITICAL_SECTION criticalClick;
std::queue<POINT> clickQueue;
HWND Window;
BOOL isRunning, isFocused;
PERFMON perfMon;
ID2D1Factory *xFactory;
ID2D1HwndRenderTarget* xTarget;
ID2D1SolidColorBrush* brush, *textBrush;
IDWriteFactory* writer;
IDWriteTextFormat* contentTextFormat;
const int circleCount = 10;
const int rectangleCount = 5;
int windowWidth, windowHeight;
int previousWindowWidth, previousWindowHeight;
int drawableCircleCount;
CIRCLE circles[1500];
RECTANGLE rectangles[rectangleCount];

void DisplayWindow();
void MakeWindowFullScreen();
void InitializeDirect();
void GenerateCircles();
void StartMessageLoop();
LRESULT CALLBACK EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void ControlFPS(FPS_CONTROLLER* fps, PERFMON* perf);
void ProcessInput();
void Render();
void DrawCircles();
void DrawDebugText();
void DrawRectangles();
void InitializeThread();
DWORD PollMouseOver(void* param);
DWORD PollLeftClick(void* param);