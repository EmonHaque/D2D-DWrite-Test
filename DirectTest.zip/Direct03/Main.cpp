#include "Main.h"

void make100() { drawableCircleCount = 100; }
void make250() { drawableCircleCount = 250; }
void make500() { drawableCircleCount = 500; }
void make1000() { drawableCircleCount = 1000; }
void make1500() { drawableCircleCount = 1500; }

//int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
int main() {
	isFullScreen = FALSE;
	drawableCircleCount = 100;
	InitializeCriticalSection(&criticalClick);
	DisplayWindow();
	InitializeDirect();
	GenerateCircles();
	InitializeThread();
	StartMessageLoop();
	DeleteCriticalSection(&criticalClick);
	return 0;
}
LRESULT EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LRESULT res = 0;
	static RECT borderThickness;
	switch (msg) {
		case WM_CLOSE:
		case WM_DESTROY: {
			PostQuitMessage(0);
			isRunning = FALSE;
		} break;
		case WM_SIZE: {
			windowWidth = LOWORD(lParam);
			windowHeight = HIWORD(lParam);
			if (xTarget) {
				xTarget->Resize(D2D1::SizeU(windowWidth, windowHeight));
				for (int i = 0; i < circleCount; i++) {
					circles[i].item.point.x = circles[i].item.point.x / previousWindowWidth * windowWidth;
					circles[i].item.point.y = circles[i].item.point.y / previousWindowHeight * windowHeight;
				}

				float width = 100.f;
				float height = 50.f;
				float top = 10;
				float left = windowWidth - 110;
				for (int i = 0; i < rectangleCount; i++) {
					rectangles[i].item.left = left;
					rectangles[i].item.top = top;
					rectangles[i].item.right = left + width;
					rectangles[i].item.bottom = top + height;
					top += (height + 10);
				}
			}
			previousWindowWidth = windowWidth;
			previousWindowHeight = windowHeight;
		} break;
		case WM_MOUSEMOVE: {
			if (!isMouseOver) {
				isMouseOver = TRUE;
				SetEvent(mouseOverEvent);
				TRACKMOUSEEVENT tme = { sizeof(tme) };
				tme.dwFlags = TME_LEAVE;
				tme.hwndTrack = hwnd;
				TrackMouseEvent(&tme);
			}
		} break;
		case WM_MOUSELEAVE: {
			isMouseOver = false;
			ResetEvent(mouseOverEvent);
		} break;
		case WM_LBUTTONUP: {
			POINT point;
			GetCursorPos(&point);
			ScreenToClient(hwnd, &point);

			EnterCriticalSection(&criticalClick);
			clickQueue.push(point);
			LeaveCriticalSection(&criticalClick);
			SetEvent(leftClickEvent);
		} break;
		default:
			res = DefWindowProc(hwnd, msg, wParam, lParam);
			break;
	}
	return res;
}
void DisplayWindow() {
	HINSTANCE h = GetModuleHandle(0);
	WNDCLASSEX wclass = { 0 };
	wclass.cbSize = sizeof(wclass);
	wclass.style = CS_VREDRAW | CS_HREDRAW;
	wclass.hInstance = h;
	wclass.hCursor = LoadCursor(0, IDC_ARROW);
	wclass.lpfnWndProc = EventHandler;
	wclass.lpszClassName = APP_NAME;
	RegisterClassEx(&wclass);
	int u = CW_USEDEFAULT;
	Window = CreateWindowEx(0, APP_NAME, APP_NAME, WS_OVERLAPPEDWINDOW|WS_VISIBLE, u, u, u, u, 0, 0, h, 0);
}
void MakeWindowFullScreen() {
	perfMon.framesRendered = 0;
	perfMon.monitorInfo.cbSize = sizeof(MONITORINFO);;
	GetMonitorInfo(MonitorFromWindow(Window, MONITOR_DEFAULTTOPRIMARY), &perfMon.monitorInfo);
	perfMon.screenHeight = perfMon.monitorInfo.rcMonitor.bottom - perfMon.monitorInfo.rcMonitor.top;
	perfMon.screenWidth = perfMon.monitorInfo.rcMonitor.right - perfMon.monitorInfo.rcMonitor.left;
	SetWindowLongPtr(Window, GWL_STYLE, WS_VISIBLE);
	windowWidth = perfMon.screenWidth;
	windowHeight = perfMon.screenHeight;
	SetWindowPos(Window, HWND_NOTOPMOST, perfMon.monitorInfo.rcMonitor.left, perfMon.monitorInfo.rcMonitor.top, perfMon.screenWidth, perfMon.screenHeight, SWP_FRAMECHANGED);
}
void InitializeDirect() {
	D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &xFactory);
	//D2D1::RenderTargetProperties(
	//	D2D1_RENDER_TARGET_TYPE_DEFAULT,
	//	D2D1::PixelFormat(DXGI_FORMAT_UNKNOWN, D2D1_ALPHA_MODE_PREMULTIPLIED))
	xFactory->CreateHwndRenderTarget(
		D2D1::RenderTargetProperties(),
		D2D1::HwndRenderTargetProperties(
			Window, 
			D2D1::SizeU(windowWidth, windowHeight), 
			D2D1_PRESENT_OPTIONS_IMMEDIATELY),
		&xTarget);

	xTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &brush);
	xTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::White), &textBrush);

	DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&writer));
	writer->CreateTextFormat(
		L"Arial",                // Font family name.
		NULL,                    // Font collection (NULL sets it to use the system font collection).
		DWRITE_FONT_WEIGHT_BOLD,
		DWRITE_FONT_STYLE_NORMAL,
		DWRITE_FONT_STRETCH_NORMAL,
		30,
		L"en-us",
		&contentTextFormat
	);
}
void GenerateCircles() {
	CIRCLE circle;
	for (int i = 0; i < 1500; i++) {
		int radius = rand() % 100;
		circle.item = D2D1::Ellipse(
			D2D1::Point2F(rand() % windowWidth, rand() % windowHeight),
			radius,
			radius
		);
		circle.grow = radius > 50 ? FALSE : TRUE;
		xTarget->CreateSolidColorBrush(D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f), &circle.brush);
		circles[i] = circle;
	}
	RECTANGLE rect;
	float width = 100.f;
	float height = 50.f;
	float top = 10;
	float left = windowWidth - 110;

	for (int i = 0; i < rectangleCount; i++) {
		float x = left;
		float y = top;
		float right = x + width;
		float bottom = y + height;

		xTarget->CreateSolidColorBrush(D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f), &rect.brush);
		rect.isMouseOver = FALSE;
		rect.normal = rect.brush->GetColor();
		rect.item = D2D1::RectF(x, y, right, bottom);

		switch (i) {
			case 0: rect.onClick = make100; rect.name = L"100"; break;
			case 1: rect.onClick = make250; rect.name = L"250"; break;
			case 2: rect.onClick = make500; rect.name = L"500"; break;
			case 3: rect.onClick = make1000; rect.name = L"1000"; break;
			case 4: rect.onClick = make1500; rect.name = L"1500"; break;
		}
		rectangles[i] = rect;
		top += (height + 10);
	}
}
void InitializeThread() {
	mouseOverThread = CreateThread(0, 0, PollMouseOver, 0, 0, 0);
	leftClickThread = CreateThread(0, 0, PollLeftClick, 0, 0, 0);
	mouseOverEvent = CreateEvent(0, TRUE, FALSE, L"MouseOverEvent");
	leftClickEvent = CreateEvent(0, TRUE, FALSE, L"LeftClickEvent");
}
DWORD PollMouseOver(void* param) {
	while (isRunning) {
		WaitForSingleObject(mouseOverEvent, INFINITE);
		POINT point;
		GetCursorPos(&point);
		ScreenToClient(Window, &point);
		for (int i = 0; i < rectangleCount; i++) {
			if (point.x > rectangles[i].item.left &&
				point.x < rectangles[i].item.right &&
				point.y > rectangles[i].item.top &&
				point.y < rectangles[i].item.bottom) {
				rectangles[i].isMouseOver = TRUE;
			}
			else {
				rectangles[i].isMouseOver = FALSE;
			}
		}
		Sleep(5);
	}
	CloseHandle(mouseOverThread);
	CloseHandle(mouseOverEvent);
	return 0;
}
DWORD PollLeftClick(void* param) {
	while (isRunning) {
		WaitForSingleObject(leftClickEvent, INFINITE);
		if (clickQueue.empty()) {
			Sleep(5);
			continue;
		}

		EnterCriticalSection(&criticalClick);
		POINT point = clickQueue.front();
		clickQueue.pop();
		LeaveCriticalSection(&criticalClick);

		for (int i = 0; i < rectangleCount; i++) {
			if (point.x > rectangles[i].item.left &&
				point.x < rectangles[i].item.right &&
				point.y > rectangles[i].item.top &&
				point.y < rectangles[i].item.bottom) {
				rectangles[i].onClick();
			}
		}
		ResetEvent(leftClickEvent);
		Sleep(5);
	}
	CloseHandle(leftClickThread);
	CloseHandle(leftClickEvent);
	return 0;
}
void StartMessageLoop() {
	isRunning = TRUE;
	NTTime ntTime;
	HMODULE ntHandle = GetModuleHandleA("ntdll.dll");
	if ((ntTime = (NTTime)GetProcAddress(ntHandle, "NtQueryTimerResolution")) == NULL) {
		MessageBox(0, L"Failed loading ntdll.dll", L"Error", MB_OK | MB_ICONERROR);
		//return 0;
	}
	ntTime(&perfMon.MinTimerRes, &perfMon.MaxTimerRes, &perfMon.CurrentTimerRes);

	timeBeginPeriod(1);
	perfMon.displayData = TRUE;
	perfMon.FPSCalcInterval = 120;
	FPS_CONTROLLER fps = { 0 };
	fps.process = GetCurrentProcess();
	fps.targetMicroSecPerFrame = 16667;
	GetSystemInfo(&perfMon.systemInfo);
	QueryPerformanceFrequency((LARGE_INTEGER*)&perfMon.frequency);
	GetSystemTimeAsFileTime((FILETIME*)&perfMon.previousSystemTime);
	MSG msg;
	while (isRunning) {
		QueryPerformanceCounter((LARGE_INTEGER*)&fps.frameStart);
		while (PeekMessage(&msg, 0, 0, 0, PM_REMOVE) > 0) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		ProcessInput();
		Render();
		ControlFPS(&fps, &perfMon);
	}
}
void ControlFPS(FPS_CONTROLLER* fps, PERFMON* perf) {
	QueryPerformanceCounter((LARGE_INTEGER*)&fps->frameEnd);
	fps->elapsedMicroSeconds = fps->frameEnd - fps->frameStart;
	fps->elapsedMicroSeconds *= 1000000;
	fps->elapsedMicroSeconds /= perf->frequency;
	perf->framesRendered++;
	fps->realTotalMicroSeconds += fps->elapsedMicroSeconds;

	while (fps->elapsedMicroSeconds < fps->targetMicroSecPerFrame) {
		fps->elapsedMicroSeconds = fps->frameEnd - fps->frameStart;
		fps->elapsedMicroSeconds *= 1000000;
		fps->elapsedMicroSeconds /= perf->frequency;
		QueryPerformanceCounter((LARGE_INTEGER*)&fps->frameEnd);
		if (fps->elapsedMicroSeconds < (fps->targetMicroSecPerFrame * 0.75f)) {
			Sleep(1); // Play around sleep time for different monitor resolution and check CPU usage
		}
	}
	fps->cooketTotalMicroSeconds += fps->elapsedMicroSeconds;

	if ((perf->framesRendered % perf->FPSCalcInterval) == 0) {
		GetSystemTimeAsFileTime((FILETIME*)&perf->currentSystemTime);
		GetProcessTimes(fps->process,
			&fps->processCreationTime,
			&fps->processExitTime,
			(FILETIME*)&fps->currentKernelCPUTime,
			(FILETIME*)&fps->currentUserCPUTime);

		perf->cpuPercent = (fps->currentKernelCPUTime - fps->previousKernelCPUTime) + (fps->currentUserCPUTime - fps->previousUserCPUTime);
		perf->cpuPercent /= (perf->currentSystemTime - perf->previousSystemTime); // check
		perf->cpuPercent /= perf->systemInfo.dwNumberOfProcessors;
		perf->cpuPercent *= 100;

		GetProcessHandleCount(fps->process, &perf->handleCount);
		GetProcessMemoryInfo(fps->process, (PROCESS_MEMORY_COUNTERS*)&perf->memInfo, sizeof(perf->memInfo));
		perf->realFPS = 1.0f / ((fps->realTotalMicroSeconds / perf->FPSCalcInterval) * 0.000001f);
		perf->cookedFPS = 1.0f / ((fps->cooketTotalMicroSeconds / perf->FPSCalcInterval) * 0.000001f);
		fps->realTotalMicroSeconds = 0;
		fps->cooketTotalMicroSeconds = 0;

		fps->previousKernelCPUTime = fps->currentKernelCPUTime;
		fps->previousUserCPUTime = fps->currentUserCPUTime;
		perf->previousSystemTime = perf->currentSystemTime;
	}
}
void ProcessInput() {
	int16_t isEscape = GetAsyncKeyState(VK_ESCAPE);
	int16_t isF = GetAsyncKeyState('F');
	static int16_t wasF = 0;
	if (isEscape) {
		SendMessage(Window, WM_CLOSE, 0, 0);
		isRunning = FALSE;
	}
	if (isF && !wasF) {
		isFullScreen = !isFullScreen;
		if (isFullScreen) {
			GetWindowRect(Window, &windowRect);
			MakeWindowFullScreen();
		}
		else {
			SetWindowLongPtr(Window, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
			SetWindowPos(Window, HWND_NOTOPMOST, windowRect.left, windowRect.top, windowRect.right, windowRect.bottom, SWP_FRAMECHANGED);
		}
	}
	wasF = isF;
}
void Render() {
	xTarget->BeginDraw();
	xTarget->Clear(D2D1::ColorF(D2D1::ColorF::White,0.2f));
	xTarget->FillRectangle(D2D1::RectF(0, 0, windowWidth, windowHeight), brush);
	DrawCircles();
	DrawRectangles();
	DrawDebugText();
	xTarget->EndDraw();
}
void DrawCircles() {
	for (int i = 0; i < drawableCircleCount; i++) {
		if (circles[i].item.radiusX > 75) {
			circles[i].grow = FALSE;
		}
		else if (circles[i].item.radiusX < 10) {
			circles[i].grow = TRUE;
		}
		if (circles[i].grow) {
			circles[i].item.radiusX++;
			circles[i].item.radiusY++;
		}
		else {
			circles[i].item.radiusX--;
			circles[i].item.radiusY--;
		}
		xTarget->DrawEllipse(&circles[i].item, circles[i].brush, 3);
	}
}
void DrawRectangles() {
	contentTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
	contentTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
	for (int i = 0; i < rectangleCount; i++) {
		if (rectangles[i].isMouseOver) {
			rectangles[i].brush->SetColor(D2D1::ColorF(D2D1::ColorF::Red));
		}
		else {
			rectangles[i].brush->SetColor(rectangles[i].normal);
		}
		xTarget->FillRoundedRectangle(D2D1::RoundedRect(rectangles[i].item, 10, 10), rectangles[i].brush);
		xTarget->DrawText(
			rectangles[i].name,
			wcslen(rectangles[i].name),
			contentTextFormat,
			D2D1::RectF(rectangles[i].item.left, rectangles[i].item.top, rectangles[i].item.right, rectangles[i].item.bottom),
			textBrush);
	}
}
void DrawDebugText() {
	contentTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
	contentTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);

	int y = 10;
	int bottom = 30;

	wchar_t buff[128] = { 0 };
	_swprintf(buff, L"Real FPS: %.02f", perfMon.realFPS);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Cooked FPS: %.02f", perfMon.cookedFPS);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Min Timer: %.02f", perfMon.MinTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Max Timer: %.02f", perfMon.MaxTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Current Timer: %.02f", perfMon.CurrentTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Handles: %lu", perfMon.handleCount);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Memory Usage: %lu MB", perfMon.memInfo.PrivateUsage / (1024 * 1024));
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"CPU Usage: %.02f %%", perfMon.cpuPercent);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"Surface: %dx%d", windowWidth, windowHeight);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);

	y += bottom;
	_swprintf(buff, L"No. of Circle: %d", drawableCircleCount);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, y, windowWidth, y + bottom), textBrush);
}