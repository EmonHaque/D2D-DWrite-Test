#pragma once
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "Dwmapi.lib");

#include <Windows.h>
#include <d2d1.h>
#include <dwrite.h>
#include <dwmapi.h>
#include <stdint.h>
#include <stdio.h>
#include "Structs.h"

#define NO_STRICT
#define APP_NAME L"Direct Test"
typedef LONG(NTAPI* NTTime) (PULONG min, PULONG max, PULONG current);

HWND Window;
BOOL isRunning, isFocused;
PERFMON perfMon;
ID2D1Factory *xFactory;
ID2D1HwndRenderTarget* xTarget;
//ID2D1DCRenderTarget* xTarget;
ID2D1SolidColorBrush* brush, *textBrush;
IDWriteFactory* writer;
IDWriteTextFormat* contentTextFormat;
int windowWidth, windowHeight;
int previousWindowWidth, previousWindowHeight;
const int circleCount = 100;
const int rectangleCount = 5;
CIRCLE circles[circleCount];
RECTANGLE rectangles[rectangleCount];

void DisplayWindow();
void MakeWindowFullScreen();
void InitializeDirect();
void GenerateCircles();
void StartMessageLoop();
LRESULT CALLBACK EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void ControlFPS(FPS_CONTROLLER* fps, PERFMON* perf);
void ProcessInput();
void Render();
void DrawCircles();
void DrawDebugText();
void DrawRectangles();