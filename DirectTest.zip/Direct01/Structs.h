#pragma once
#include <Windows.h>
#include <stdint.h>
#include <Psapi.h>

typedef struct {
	D2D1_ELLIPSE item;
	BOOL grow;
	ID2D1SolidColorBrush* brush;
} CIRCLE;

typedef struct {
	D2D1_RECT_F item;
	ID2D1SolidColorBrush* brush;
} RECTANGLE;

typedef struct {
	uint64_t framesRendered;
	float realFPS;
	float cookedFPS;
	uint64_t FPSCalcInterval;
	MONITORINFO monitorInfo;
	int32_t screenWidth;
	int32_t screenHeight;
	int64_t frequency;
	BOOL displayData;
	ULONG MinTimerRes;
	ULONG MaxTimerRes;
	ULONG CurrentTimerRes;
	DWORD handleCount;
	PROCESS_MEMORY_COUNTERS_EX memInfo;
	uint64_t currentSystemTime;
	uint64_t previousSystemTime;
	SYSTEM_INFO systemInfo;
	double cpuPercent;
} PERFMON;

typedef struct {
	HANDLE process;
	int16_t targetMicroSecPerFrame;
	int64_t frameStart;
	int64_t frameEnd;
	int64_t elapsedMicroSeconds;
	int64_t realTotalMicroSeconds;
	int64_t cooketTotalMicroSeconds;
	FILETIME processCreationTime;
	FILETIME processExitTime;
	int64_t currentUserCPUTime;
	int64_t currentKernelCPUTime;
	int64_t previousUserCPUTime;
	int64_t previousKernelCPUTime;
} FPS_CONTROLLER;
