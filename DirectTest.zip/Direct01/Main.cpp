#define _CRT_SECURE_NO_WARNINGS
#include "Main.h"

BOOL isFullScreen;
RECT windowRect;

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
	isFullScreen = FALSE;
	DisplayWindow();	
	InitializeDirect();
	GenerateCircles();
	StartMessageLoop();
	return 0;
}
LRESULT CALLBACK EventHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	LRESULT res = 0;
	switch (msg) {
		case WM_CLOSE:
		case WM_DESTROY: {
			PostQuitMessage(0);
			isRunning = FALSE;
		} break;
		case WM_SIZE: {
			windowWidth = LOWORD(lParam);
			windowHeight = HIWORD(lParam);
			if (xTarget) {
				xTarget->Resize(D2D1::SizeU(windowWidth, windowHeight));
				for (int i = 0; i < circleCount; i++) {
					circles[i].item.point.x = circles[i].item.point.x / previousWindowWidth * windowWidth;
					circles[i].item.point.y = circles[i].item.point.y / previousWindowHeight * windowHeight;
				}
			}		
			previousWindowWidth = windowWidth;
			previousWindowHeight = windowHeight;
		} break;
		default:
			res = DefWindowProc(hwnd, msg, wParam, lParam);
			break;
	}
	OutputDebugStringA("Here");
	return res;
}
void DisplayWindow() {
	HINSTANCE h = GetModuleHandle(0);
	WNDCLASSEX wclass = { 0 };
	wclass.cbSize = sizeof(wclass);
	wclass.style = CS_VREDRAW | CS_HREDRAW;
	wclass.hInstance = h;
	wclass.hCursor = LoadCursor(h, IDC_ARROW);
	wclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wclass.lpfnWndProc = EventHandler;
	wclass.lpszClassName = APP_NAME;
	RegisterClassEx(&wclass);
	int u = CW_USEDEFAULT;
	Window = CreateWindowEx(0, APP_NAME, APP_NAME, WS_OVERLAPPEDWINDOW | WS_VISIBLE, u, u, u, u, 0, 0, h, 0);
}
void MakeWindowFullScreen() {
	perfMon.framesRendered = 0;
	perfMon.monitorInfo.cbSize = sizeof(MONITORINFO);;
	GetMonitorInfo(MonitorFromWindow(Window, MONITOR_DEFAULTTOPRIMARY), &perfMon.monitorInfo);
	perfMon.screenHeight = perfMon.monitorInfo.rcMonitor.bottom - perfMon.monitorInfo.rcMonitor.top;
	perfMon.screenWidth = perfMon.monitorInfo.rcMonitor.right - perfMon.monitorInfo.rcMonitor.left;
	SetWindowLongPtr(Window, GWL_STYLE, WS_VISIBLE);
	windowWidth = perfMon.screenWidth;
	windowHeight = perfMon.screenHeight;
	SetWindowPos(Window, HWND_NOTOPMOST, perfMon.monitorInfo.rcMonitor.left, perfMon.monitorInfo.rcMonitor.top, perfMon.screenWidth, perfMon.screenHeight, SWP_FRAMECHANGED);
}
void InitializeDirect() {
	D2D1CreateFactory(D2D1_FACTORY_TYPE_MULTI_THREADED, &xFactory);
#pragma region HWNDTarget
	xFactory->CreateHwndRenderTarget(
	D2D1::RenderTargetProperties(),
	D2D1::HwndRenderTargetProperties(Window, D2D1::SizeU(windowWidth, windowHeight), D2D1_PRESENT_OPTIONS_IMMEDIATELY),
	&xTarget);
#pragma endregion

#pragma region DCTarget
	/*D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties(
		D2D1_RENDER_TARGET_TYPE_DEFAULT,
		D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE),
		0,
		0,
		D2D1_RENDER_TARGET_USAGE_NONE,
		D2D1_FEATURE_LEVEL_DEFAULT
	);
	xFactory->CreateDCRenderTarget(&props, &xTarget);
	RECT rc;
	GetClientRect(window, &rc);
	xTarget->BindDC(GetDC(window), &rc);*/
#pragma endregion

	xTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &brush);
	xTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::White), &textBrush);
	
	DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(&writer));
	writer->CreateTextFormat(
		L"Arial",                // Font family name.
		NULL,                    // Font collection (NULL sets it to use the system font collection).
		DWRITE_FONT_WEIGHT_BOLD,
		DWRITE_FONT_STYLE_NORMAL,
		DWRITE_FONT_STRETCH_NORMAL,
		50.0f,
		L"en-us",
		&contentTextFormat
	);
	
	contentTextFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
	contentTextFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
}
void GenerateCircles() {
	CIRCLE circle;
	for (int i = 0; i < circleCount; i++) {
		int radius = rand() % 100;
		circle.item = D2D1::Ellipse(
			D2D1::Point2F(rand() % windowWidth, rand() % windowHeight),
			radius,
			radius
		);
		circle.grow = radius > 50 ? FALSE : TRUE;
		xTarget->CreateSolidColorBrush(D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f), &circle.brush);
		circles[i] = circle;
	}
	RECTANGLE rect;
	int hw = windowWidth / 2;
	int hh = windowHeight / 2;
	float width = 100.f;
	float height = 50.f;
	for (int i = 0; i < rectangleCount; i++) {	
		float left = (rand() % hw) + (hw - width);
		float top = (rand() % hh) + (hh - height);
		float right = left + 100;
		float bottom = top + 50;
		xTarget->CreateSolidColorBrush(D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f), &rect.brush);
		rect.item = D2D1::RectF(left, top, right, bottom);
		rectangles[i] = rect;
	}
}
void StartMessageLoop() {
	isRunning = TRUE;
	NTTime ntTime;
	HMODULE ntHandle = GetModuleHandleA("ntdll.dll");
	if ((ntTime = (NTTime)GetProcAddress(ntHandle, "NtQueryTimerResolution")) == NULL) {
		MessageBox(0, L"Failed loading ntdll.dll", L"Error", MB_OK | MB_ICONERROR);
		//return 0;
	}
	ntTime(&perfMon.MinTimerRes, &perfMon.MaxTimerRes, &perfMon.CurrentTimerRes);

	timeBeginPeriod(1);
	perfMon.displayData = TRUE;
	perfMon.FPSCalcInterval = 120;
	FPS_CONTROLLER fps = {0};
	fps.process = GetCurrentProcess();
	fps.targetMicroSecPerFrame = 16667;
	GetSystemInfo(&perfMon.systemInfo);
	QueryPerformanceFrequency((LARGE_INTEGER*)&perfMon.frequency);	
	GetSystemTimeAsFileTime((FILETIME*) & perfMon.previousSystemTime);
	MSG msg;
	while (isRunning) {
		QueryPerformanceCounter((LARGE_INTEGER*)&fps.frameStart);
		while (PeekMessage(&msg, 0, 0, 0, PM_REMOVE) > 0) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		ProcessInput();
		Render();
		ControlFPS(&fps, &perfMon);
	}
}
void ControlFPS(FPS_CONTROLLER* fps, PERFMON *perf) {
	QueryPerformanceCounter((LARGE_INTEGER*)&fps->frameEnd);
	fps->elapsedMicroSeconds = fps->frameEnd - fps->frameStart;
	fps->elapsedMicroSeconds *= 1000000;
	fps->elapsedMicroSeconds /= perf->frequency;
	perf->framesRendered++;
	fps->realTotalMicroSeconds += fps->elapsedMicroSeconds;

	while (fps->elapsedMicroSeconds < fps->targetMicroSecPerFrame) {
		fps->elapsedMicroSeconds = fps->frameEnd - fps->frameStart;
		fps->elapsedMicroSeconds *= 1000000;
		fps->elapsedMicroSeconds /= perf->frequency;
		QueryPerformanceCounter((LARGE_INTEGER*)&fps->frameEnd);
		if (fps->elapsedMicroSeconds < (fps->targetMicroSecPerFrame * 0.75f)) {
			Sleep(1); // Play around sleep time for different monitor resolution and check CPU usage
		}
	}
	fps->cooketTotalMicroSeconds += fps->elapsedMicroSeconds;

	if ((perf->framesRendered % perf->FPSCalcInterval) == 0) {
		GetSystemTimeAsFileTime((FILETIME*)&perf->currentSystemTime);
		GetProcessTimes(fps->process,
			&fps->processCreationTime,
			&fps->processExitTime,
			(FILETIME*)&fps->currentKernelCPUTime,
			(FILETIME*)&fps->currentUserCPUTime);

		perf->cpuPercent = (fps->currentKernelCPUTime - fps->previousKernelCPUTime) + (fps->currentUserCPUTime - fps->previousUserCPUTime);
		perf->cpuPercent /= (perf->currentSystemTime - perf->previousSystemTime); // check
		perf->cpuPercent /= perf->systemInfo.dwNumberOfProcessors;
		perf->cpuPercent *= 100;

		GetProcessHandleCount(fps->process, &perf->handleCount);
		GetProcessMemoryInfo(fps->process, (PROCESS_MEMORY_COUNTERS*)&perf->memInfo, sizeof(perf->memInfo));
		perf->realFPS = 1.0f / ((fps->realTotalMicroSeconds / perf->FPSCalcInterval) * 0.000001f);
		perf->cookedFPS = 1.0f / ((fps->cooketTotalMicroSeconds / perf->FPSCalcInterval) * 0.000001f);
		fps->realTotalMicroSeconds = 0;
		fps->cooketTotalMicroSeconds = 0;

		fps->previousKernelCPUTime = fps->currentKernelCPUTime;
		fps->previousUserCPUTime = fps->currentUserCPUTime;
		perf->previousSystemTime = perf->currentSystemTime;
	}
}
void ProcessInput() {
	int16_t isEscape = GetAsyncKeyState(VK_ESCAPE);
	int16_t isF = GetAsyncKeyState('F');
	static int16_t wasF = 0;
	if (isEscape) {
		SendMessage(Window, WM_CLOSE, 0, 0);
		isRunning = FALSE;
	}
	if (isF && !wasF) {
		isFullScreen = !isFullScreen;
		if (isFullScreen) {
			GetWindowRect(Window, &windowRect);
			MakeWindowFullScreen();
		}
		else {
			SetWindowLongPtr(Window, GWL_STYLE, WS_VISIBLE|WS_OVERLAPPEDWINDOW);
			SetWindowPos(Window, HWND_NOTOPMOST, windowRect.left, windowRect.top, windowRect.right, windowRect.bottom, SWP_FRAMECHANGED);
		}
	}
	wasF = isF;
}
void Render() {
	xTarget->BeginDraw();
	xTarget->Clear(D2D1::ColorF(D2D1::ColorF::Black));
	xTarget->FillRectangle(D2D1::RectF(0, 0, windowWidth, windowHeight), brush);
	DrawCircles();
	//DrawRectangles();
	DrawDebugText();
	xTarget->EndDraw();
}
void DrawCircles() {
	for (int i = 0; i < circleCount; i++) {
		if (circles[i].item.radiusX > 75) {
			circles[i].grow = FALSE;
		}
		if (circles[i].item.radiusX < 10) {
			circles[i].grow = TRUE;
		}
		if (circles[i].grow) {
			circles[i].item.radiusX++;
			circles[i].item.radiusY++;
		}
		else {
			circles[i].item.radiusX--;
			circles[i].item.radiusY--;
		}
		
		//circleBrush->SetColor(D2D1::ColorF((rand() % 100) / 100.f, (rand() % 100) / 100.f, (rand() % 100) / 100.f));
		xTarget->DrawEllipse(&circles[i].item, circles[i].brush, 3);
	}
}
void DrawRectangles() {
	for (int i = 0; i < rectangleCount; i++) {
		xTarget->FillRectangle(rectangles[i].item, rectangles[i].brush);
	}
}
void DrawDebugText() {
	wchar_t buff[128] = { 0 };
	_swprintf(buff, L"Real FPS: %.02f", perfMon.realFPS);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 10, windowWidth, 60), textBrush);

	_swprintf(buff, L"Cooked FPS: %.02f", perfMon.cookedFPS);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 60, windowWidth, 110), textBrush);

	_swprintf(buff, L"Min Timer: %.02f", perfMon.MinTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 110, windowWidth, 160), textBrush);

	_swprintf(buff, L"Max Timer: %.02f", perfMon.MaxTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 160, windowWidth, 210), textBrush);

	_swprintf(buff, L"Current Timer: %.02f", perfMon.CurrentTimerRes / 10000.f);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 210, windowWidth, 260), textBrush);

	_swprintf(buff, L"Handles: %lu", perfMon.handleCount);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 260, windowWidth, 310), textBrush);

	_swprintf(buff, L"Memory Usage: %lu MB", perfMon.memInfo.PrivateUsage / (1024 * 1024));
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 310, windowWidth, 360), textBrush);

	_swprintf(buff, L"CPU Usage: %.02f %%", perfMon.cpuPercent);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 360, windowWidth, 410), textBrush);

	_swprintf(buff, L"Surface: %dx%d", windowWidth, windowHeight);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 410, windowWidth, 460), textBrush);

	_swprintf(buff, L"No. of Circle: %d", circleCount);
	xTarget->DrawText(buff, wcslen(buff), contentTextFormat, D2D1::RectF(10, 460, windowWidth, 510), textBrush);
}